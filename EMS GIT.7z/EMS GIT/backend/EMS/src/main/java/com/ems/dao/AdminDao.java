package com.ems.dao;

import java.util.Base64;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;
import com.ems.bean.Admin;
import com.ems.bean.Employee;

@Repository
public class AdminDao implements IAdminDao{

	@Autowired
	MongoTemplate mongoTemplate;
	
	@Override
	public Admin checkLoginDetails(String userName, String password) {
		Query query=new Query();
		query.addCriteria(Criteria.where("userName").is(userName));
		Admin admin=mongoTemplate.findOne(query, Admin.class);
		if(admin != null) {
			if(admin.getPassword().matches(password))
				return admin;
		}
		return null;
	}

	@Override
	public List<Employee> viewEmployeeDetails() {
		List<Employee> employeeList=mongoTemplate.findAll(Employee.class);
		return employeeList;
	}

	@Override
	public Boolean addEmployeeDetails(Employee employee) {
		if(mongoTemplate.findById(employee.getEmail(), Employee.class)!=null) {
			return false;
		}
		employee.setPassword(toEncode(employee.getPassword()));
		if(mongoTemplate.insert(employee)!=null) {
			
			return true;
		}
		return false;
	}
	
	public static String toEncode(String message) {
		 return Base64.getEncoder().encodeToString(message.getBytes());
	}

	@Override
	public Boolean deleteEmployeeDetails(String userName) {
		if(mongoTemplate.findById(userName, Employee.class)!=null) {
			Query query=new Query();
			query.addCriteria(Criteria.where("_id").is(userName));
			mongoTemplate.remove(query,Employee.class);
			return true;
		}
		return false;
	}

	@Override
	public boolean addDetails(Admin admin) {
		Query query=new Query();
		query.addCriteria(Criteria.where("userName").is(admin.getUserName()));
		if(mongoTemplate.findOne(query, Admin.class)==null)
		{
			mongoTemplate.insert(admin);
			return true;
		}
		return false;
		}

}

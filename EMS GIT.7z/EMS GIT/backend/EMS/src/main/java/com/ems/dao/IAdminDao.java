package com.ems.dao;

import java.util.List;

import com.ems.bean.Admin;
import com.ems.bean.Employee;

public interface IAdminDao {

	Admin checkLoginDetails(String userName, String password);

	List<Employee> viewEmployeeDetails();
	
	Boolean addEmployeeDetails(Employee employee);
	
	Boolean deleteEmployeeDetails(String userName);

	boolean addDetails(Admin admin);
}

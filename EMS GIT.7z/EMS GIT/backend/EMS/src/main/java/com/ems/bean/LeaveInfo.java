package com.ems.bean;

import java.time.LocalDate;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class LeaveInfo {
	private LocalDate leaveStartDate;
	private LocalDate leaveEndDate;
	private String reason;
	public LocalDate getLeaveStartDate() {
		return leaveStartDate;
	}
	public void setLeaveStartDate(LocalDate leaveStartDate) {
		this.leaveStartDate = leaveStartDate;
	}
	public LocalDate getLeaveEndDate() {
		return leaveEndDate;
	}
	public void setLeaveEndDate(LocalDate leaveEndDate) {
		this.leaveEndDate = leaveEndDate;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public LeaveInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public LeaveInfo(LocalDate leaveStartDate, LocalDate leaveEndDate, String reason) {
		super();
		this.leaveStartDate = leaveStartDate;
		this.leaveEndDate = leaveEndDate;
		this.reason = reason;
	}
}

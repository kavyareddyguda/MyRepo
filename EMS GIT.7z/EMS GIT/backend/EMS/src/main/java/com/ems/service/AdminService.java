package com.ems.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ems.bean.Admin;
import com.ems.bean.Employee;
import com.ems.dao.IAdminDao;


@Service
public class AdminService implements IAdminService{
	
	@Autowired
	IAdminDao iAdminDao;

	@Override
	public Admin checkLoginDetails(String userName, String password) {	
		return iAdminDao.checkLoginDetails(userName, password);
	}

	@Override
	public List<Employee> viewEmployeeDetails() {	
		return iAdminDao.viewEmployeeDetails();
	}

	@Override
	public Boolean addEmployeeDetails(Employee employee) {
		return iAdminDao.addEmployeeDetails(employee);
	}

	@Override
	public Boolean deleteEmployeeDetails(String userName) {
		return iAdminDao.deleteEmployeeDetails(userName);
	}

	@Override
	public boolean addDetails(Admin admin) {
		return iAdminDao.addDetails(admin);
	}
	
}

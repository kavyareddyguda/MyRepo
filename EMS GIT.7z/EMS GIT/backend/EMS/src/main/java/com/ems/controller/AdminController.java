package com.ems.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ems.bean.Admin;
import com.ems.bean.Employee;
import com.ems.service.IAdminService;


@RestController
@RequestMapping("/admin")
@CrossOrigin(origins="http://localhost:4200")
public class AdminController {
	
	Logger logger=LoggerFactory.getLogger(AdminController.class);
	
	@Autowired
	IAdminService iAdminService;
	
	@GetMapping("/login")
	public Admin checkLoginDetails(@RequestParam String userName, String password) {
		Admin admin=iAdminService.checkLoginDetails(userName,password);
		if(admin != null)
		{
			logger.trace("Admin got logged in ...");
			return admin;
		}
		logger.trace("Admini credentials are wrong!");
		return null;
	}
	
	@PostMapping("/register")
	public Boolean registerAdmin(@RequestBody Admin admin) {
		if(iAdminService.addDetails(admin))
			return true;
		return false;
	}

	
	@GetMapping("/viewAllEmployees")
	public List<Employee> viewAllEmployees(){
		List<Employee> employeeList=iAdminService.viewEmployeeDetails();
		if(employeeList==null) {
			logger.trace("Employees list is null");
			return null;
		}
		logger.trace("Employees list is sent");
		return employeeList;
		
	}
	
	
	@PostMapping("/addEmployee")
	public Boolean addEmployeeDetails(@RequestBody Employee employee) {
		if(employee!=null)
		{
			logger.trace("Employee details are added");
			return iAdminService.addEmployeeDetails(employee);
		}
		logger.trace("Adding of employing details is not done");
		return false;
	}
	
	@DeleteMapping("/deleteEmployee")
	Boolean deleteEmployeeDetails(@RequestParam String userName) {
		logger.trace("employee details deleting is started....");
		return iAdminService.deleteEmployeeDetails(userName);
	}
}

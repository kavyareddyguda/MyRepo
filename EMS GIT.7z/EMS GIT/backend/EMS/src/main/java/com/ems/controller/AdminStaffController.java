package com.ems.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ems.bean.AdminStaff;
import com.ems.service.IAdminStaffService;

@RestController
@RequestMapping("/adminstaff")
@CrossOrigin(origins="http://localhost:4200")
public class AdminStaffController {
	
	@Autowired
	IAdminStaffService iAdminStaffService;
	
	Logger logger=LoggerFactory.getLogger(AdminStaffController.class);
	
	@GetMapping("/login")
	public AdminStaff checkLoginDetails(@RequestParam String userName, String password) {
		AdminStaff admin=iAdminStaffService.checkLoginDetails(userName, password);
		if(admin != null)
		{
			logger.trace("Admin got logged in!!");
			return admin;
		}
		logger.trace("Admin Credentials are incorrect...");
		return null;
		
	}
	
	@PostMapping("/register")
	public Boolean registerAdmin(@RequestBody AdminStaff adminStaff) {
		logger.trace("Registration for AdminStaff is called");
		if(iAdminStaffService.addDetails(adminStaff))
			return true;
		return false;
	}
	
	@PostMapping("/updateEmployeeLeaves")
	public Boolean updateEmployeeLeaves(@RequestParam String email, Integer noOfLeavesToBeAdded) {
		logger.trace("Request for no of Leaves To be added for an employee is received");
		return iAdminStaffService.updateEmployeeLeaves(email, noOfLeavesToBeAdded);
	}
	
	@GetMapping("/calculateLOPS")
	public Double calculateLOPS(@RequestParam String email) {
		logger.trace("Request for LOPS is got...");
		return iAdminStaffService.calculateLOPS(email);
	}
	
	
	
	

}

package com.ems.bean;


import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class LeaveList {
	private List<LeaveInfo> leaveInfo;
	private Integer noOfLeaves=0;
	private Double lossOfPay=(double) 0;
	public Double getLossOfPay() {
		return lossOfPay;
	}
	public void setLossOfPay(Double lossOfPay) {
		this.lossOfPay = lossOfPay;
	}

	public List<LeaveInfo> getLeaveInfo() {
		return leaveInfo;
	}
	public void setLeaveInfo(List<LeaveInfo> leaveInfo) {
		this.leaveInfo = leaveInfo;
	}
	public Integer getNoOfLeaves() {
		return noOfLeaves;
	}
	public void setNoOfLeaves(Integer noOfLeaves) {
		this.noOfLeaves = noOfLeaves;
	}
	public LeaveList() {
		super();
		// TODO Auto-generated constructor stub
	}
	public LeaveList(List<LeaveInfo> leaveInfo, Integer noOfLeaves) {
		super();
		this.leaveInfo = leaveInfo;
		this.noOfLeaves = noOfLeaves;
	}
}

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { ViewEmployeeComponent } from './view-employee/view-employee.component';
import { AdminStaffComponent } from './admin-staff/admin-staff.component';
import { EmployeeComponent } from './employee/employee.component';
import { UpdateEmployeeLeavesComponent } from './update-employee-leaves/update-employee-leaves.component';
import { CalculateLOPSComponent } from './calculate-lops/calculate-lops.component';
import { ProfileComponent } from './profile/profile.component';
import { LeaveInfoComponent } from './leave-info/leave-info.component';
import { ApplyForLeaveComponent } from './apply-for-leave/apply-for-leave.component';
import { SavePasswordComponent } from './save-password/save-password.component';


const routes: Routes = [
  {path:'home',component:LoginComponent},
  {path:'adminhome',component:AdminHomeComponent},
  {path:'addEmployee',component:AddEmployeeComponent},
  {path:'viewEmployees',component:ViewEmployeeComponent},
  {path:'adminstaffhome',component:AdminStaffComponent},
  {path:'updateEmployeeLeaves',component:UpdateEmployeeLeavesComponent},
  {path:'calculatelop',component:CalculateLOPSComponent},
  {path:'employeehome',component:EmployeeComponent},
  {path:'profile', component:ProfileComponent},
  {path:'leaveinfo',component:LeaveInfoComponent},
  {path:'applyforleave',component:ApplyForLeaveComponent},
  {path:'savepassword',component:SavePasswordComponent},
  {path:'**',redirectTo:'/home',pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
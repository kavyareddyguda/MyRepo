import { Component, OnInit } from '@angular/core';
import { EmsService } from '../ems.service';

@Component({
  selector: 'app-view-employee',
  templateUrl: './view-employee.component.html',
  styleUrls: ['./view-employee.component.css']
})
export class ViewEmployeeComponent implements OnInit {

  employees: any[];
  message: string;

  deleteEmployee(email: string) {
    this.emsService.deleteEmployee(email).subscribe((data: any) => {
      if (data == true) {
        this.message = "deleted!! ";
      }
      else {
        this.message = "oop!! Something went wrong!!"
      }
    });
  }
  constructor(private emsService: EmsService) { }

  ngOnInit() {
    this.emsService.viewEmployees().subscribe(
      (data: any) => {
        this.employees = data;
        if (this.employees == null) {
          this.message = "No employee in the company!!!!";
        }
      }
    );
  }

  viewEmployees() {
    this.emsService.viewEmployees().subscribe(
      (data: any) => {
        this.employees = data;
        if (this.employees == null) {
          this.message = "No employee in the company!!!!";
        }
      }
    );
  }
}

import { Component, OnInit } from '@angular/core';
import { EmsService } from '../ems.service';

@Component({
  selector: 'app-update-employee-leaves',
  templateUrl: './update-employee-leaves.component.html',
  styleUrls: ['./update-employee-leaves.component.css']
})
export class UpdateEmployeeLeavesComponent implements OnInit {

  message:string;

  onSubmit(leavesUpdation:any){
    this.emsService.updateEmployeeLeaves(leavesUpdation.email,leavesUpdation.leaves).subscribe((data:any)=>{
      if(data==true){
        this.message="Successfully updated!!! ";
      }
      else{
        this.message="Oop!! Something went wrong......"
      }
    });
  }

  constructor(private emsService:EmsService) { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';
import { EmsService } from '../ems.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  employee:any;

  constructor(private emsService:EmsService) { }

  ngOnInit() {
    this.employee=this.emsService.getEmployeeDetails().subscribe((data:any)=>{
      this.employee=data;
    });
  }

}

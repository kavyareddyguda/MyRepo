import { Component, OnInit } from '@angular/core';
import { EmsService } from '../ems.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-save-password',
  templateUrl: './save-password.component.html',
  styleUrls: ['./save-password.component.css']
})
export class SavePasswordComponent implements OnInit {

  message:String;

  onSubmit(employeeForm:any){
    this.emsService.savePassword(employeeForm).subscribe((data:any)=>{
      console.log(data);
      if(data==true){
        this.message="Successfully Password is set!!!";
      }
      else{
        this.message="OOPS!!!! No employee with this email is present in the company..."
      }
    });
  }

  back(){
    this.router.navigate(['/home']);
  }

  constructor(private emsService:EmsService,private router:Router) { }

  ngOnInit() {
  }

}

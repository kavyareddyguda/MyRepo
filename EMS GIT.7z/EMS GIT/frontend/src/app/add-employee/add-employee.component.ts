import { Component, OnInit } from '@angular/core';
import { EmsService } from '../ems.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
  message:string;

  onSubmit(employeeForm:any){
    this.emsService.addEmployee(employeeForm).subscribe((data:any)=>{
      if(data==true){
        this.message="Successfully Added!!!";
      }
      else{
        this.message="OOPS!!!!! There's a problem in adding"
      }
    });
  }
  
  constructor(private emsService:EmsService,private router:Router) { }

  ngOnInit() {
  }

}

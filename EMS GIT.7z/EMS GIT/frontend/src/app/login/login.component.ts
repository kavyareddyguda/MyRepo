import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { EmsService } from '../ems.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user:any;
  message:string;

  onSubmit(loginForm:any){
    this.emsService.loginUser(loginForm).subscribe((data:any)=>{
      this.user=data;
      if(this.user!=null)
        {
          this.emsService.setUser(this.user);
          if(loginForm.role=="admin"){
            this.router.navigate(['/adminhome']);
          }
          else if(loginForm.role=="adminstaff") {
            this.router.navigate(['/adminstaffhome']);
          }
          else{
            this.router.navigate(['/employeehome']);
          }
        }
      else{
        this.message="Invalid UserName or password!!!";
      }
    });
  }

  register(){
    this.router.navigate(['/savepassword']);
  }
  constructor(private emsService:EmsService,private router:Router) { }

  ngOnInit() {
  }

}

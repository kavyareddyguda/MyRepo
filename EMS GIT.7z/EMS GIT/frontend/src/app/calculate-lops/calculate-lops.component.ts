import { Component, OnInit } from '@angular/core';
import { EmsService } from '../ems.service';

@Component({
  selector: 'app-calculate-lops',
  templateUrl: './calculate-lops.component.html',
  styleUrls: ['./calculate-lops.component.css']
})
export class CalculateLOPSComponent implements OnInit {
  lops: any;
  message: string;

  onSubmit(lopsForm: any) {
    this.emsService.calculateLops(lopsForm.email).subscribe((data: any) => {
      if (data == -1) {
        this.message = "Oops!! Employee not found......"
      }
      else {
        this.lops = data;
        console.log(this.lops);
        this.message="Employee "+lopsForm.email+" has "+this.lops+" Rs/- of loss of pay till now";
      }
    }
    );
  }
  constructor(private emsService: EmsService) { }

  ngOnInit() {
  }

}

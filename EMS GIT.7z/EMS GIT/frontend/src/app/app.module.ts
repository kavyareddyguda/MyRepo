import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import {HttpClientModule} from '@angular/common/http';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AdminStaffComponent } from './admin-staff/admin-staff.component';
import { EmployeeComponent } from './employee/employee.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { ViewEmployeeComponent } from './view-employee/view-employee.component';
import { UpdateEmployeeLeavesComponent } from './update-employee-leaves/update-employee-leaves.component';
import { CalculateLOPSComponent } from './calculate-lops/calculate-lops.component';
import { ProfileComponent } from './profile/profile.component';
import { LeaveInfoComponent } from './leave-info/leave-info.component';
import { ApplyForLeaveComponent } from './apply-for-leave/apply-for-leave.component';
import { SavePasswordComponent } from './save-password/save-password.component';
import {DataTableModule} from 'angular-6-datatable';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    AdminHomeComponent,
    AdminStaffComponent,
    EmployeeComponent,
    AddEmployeeComponent,
    ViewEmployeeComponent,
    UpdateEmployeeLeavesComponent,
    CalculateLOPSComponent,
    ProfileComponent,
    LeaveInfoComponent,
    ApplyForLeaveComponent,
    SavePasswordComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    DataTableModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { Component, OnInit } from '@angular/core';
import { EmsService } from '../ems.service';

@Component({
  selector: 'app-apply-for-leave',
  templateUrl: './apply-for-leave.component.html',
  styleUrls: ['./apply-for-leave.component.css']
})
export class ApplyForLeaveComponent implements OnInit {

  message:string;

  onSubmit(leaveInfo:any){
    console.log(leaveInfo);
    this.emsService.applyforLeave(leaveInfo).subscribe((data:any)=>{
      if(data==true){
        this.message="Successfully leave is applied!!!"
      }
      else{
        this.message="Oops!!! Something went wrong......."
      }
    });
  }
  constructor(private emsService:EmsService) { }

  ngOnInit() {
  }

}

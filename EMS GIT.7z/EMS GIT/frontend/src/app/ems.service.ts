import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmsService {
  
  savePassword(employeeForm: any) {
    let userMail=employeeForm.email;
    let oldPassword=employeeForm.oldPassword;
    let newPassword=employeeForm.newPassword;
    return this.http.post("http://localhost:9856/employee/savePassword?email="+userMail+"&oldPassword="+oldPassword+"&newPassword="+newPassword,true);
  }

  user:any;
  userName:any;

  loginUser(userCredentials:any) {
    this.userName = userCredentials.uname;
    let password = userCredentials.password;
    let role = userCredentials.role;
    console.log(this.userName);
    if (role=="adminstaff") {
      return this.http.get("http://localhost:9856/adminstaff/login?userName="+this.userName+"&password="+password);
    }
    else if(role=="admin"){
      return this.http.get("http://localhost:9856/admin/login?userName=" + this.userName +"&password=" + password);
    }
    return this.http.get("http://localhost:9856/employee/login?email="+this.userName+"&password="+password);
  }

  viewEmployees(){
    return this.http.get("http://localhost:9856/admin/viewAllEmployees");
  }

  setUser(userCredentials:any){
    this.user=userCredentials;
  }

  getUser(){
    return this.user;
  }

  getEmployeeDetails(){
    return this.http.get("http://localhost:9856/employee/profile?email="+this.userName);
  }

  addEmployee(employee:any){
    let input={
      "employeeName":employee.name,
      "email":employee.email,
      "password":employee.password,
      "birthDate":employee.bdate,
      "address":employee.address,
      "noOfLeavesPermitted":employee.leaves
    }
    return this.http.post("http://localhost:9856/admin/addEmployee",input);
  }

  deleteEmployee(userName:string){
    return this.http.delete("http://localhost:9856/admin/deleteEmployee?userName="+userName);
  }

  updateEmployeeLeaves(email:string,noOfLeavesToBeAdded:number){
    return this.http.post("http://localhost:9856/adminstaff/updateEmployeeLeaves?email="+email+"&noOfLeavesToBeAdded="+noOfLeavesToBeAdded,true);
  }

  calculateLops(email:string){
    return this.http.get("http://localhost:9856/adminstaff/calculateLOPS?email="+email);
  }

  viewLeaveList(){
    return this.http.get("http://localhost:9856/employee/viewEmployeeAttendance?email="+this.userName);
  }

  viewNoOfLeaves(){
    return this.http.get("http://localhost:9856/employee/noOfLeaves?email="+this.userName);
  }

  viewLop(){
    return this.http.get("http://localhost:9856/employee/LOP?email="+this.userName);
  }

  applyforLeave(leaveInfo:any){
    console.log(leaveInfo);
    let leaveStartDate=leaveInfo.lsdate;
    let leaveEndDate=leaveInfo.ledate;
    let reason=leaveInfo.reason;
    console.log(this.userName);
    console.log(leaveStartDate);
    console.log(leaveEndDate);
    console.log(reason);
    return this.http.post("http://localhost:9856/employee/applyforleave?email="+this.userName+"&leaveStartDate="+leaveStartDate+"&leaveEndDate="+leaveEndDate+"&reason="+reason,true);
  }

  constructor(private http:HttpClient) { }
}

import { Component, OnInit } from '@angular/core';
import { EmsService } from '../ems.service';

@Component({
  selector: 'app-leave-info',
  templateUrl: './leave-info.component.html',
  styleUrls: ['./leave-info.component.css']
})
export class LeaveInfoComponent implements OnInit {

  leaves:any[];
  lop:any;
  noOfLeaves:any;
  message:string;

  constructor(private emsService:EmsService) { }

  ngOnInit() {
    this.emsService.viewLeaveList().subscribe((data:any)=>{
      this.leaves=data;
      if(this.leaves==null){
        this.message="WOW!!!!! you have 100% attendance";
      }
    });

    this.emsService.viewLop().subscribe((data:any)=>{
      this.lop=data;
    });
    
    this.emsService.viewNoOfLeaves().subscribe((data:any)=>{
      this.noOfLeaves=data;
    });
  }
}
